package project.Model;

public interface Shooter {
    Shot shoot();
}
