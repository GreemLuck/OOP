package core;

public class Tuple {
    private final int a;
    private final int b;

    public Tuple(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int getA(){
        return a;
    }
}
