package series.series_1.exercise;

public class Main {
    public static void main(String[] args){
        Person person = new Person("Patrick", 43);
        System.out.println(person.getName());
        System.out.println(person.getAge());
    }
}
