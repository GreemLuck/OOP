package series.series_5.exercices.exo_2;

public interface Ovipar {
    abstract void layingEggs();
}
