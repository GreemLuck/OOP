package series.series_5.exercices.exo_2;

public class Platypus extends Mammal implements Aquatic, Ovipar {
    public Platypus (int age, int weight, String sex){
        super(age, weight, sex);
    }

    @Override
    protected void doSound() {

    }

    @Override
    protected void est() {

    }

    @Override
    public void swim() {

    }

    @Override
    public void nurse() {

    }

    @Override
    public void layingEggs() {

    }
}
