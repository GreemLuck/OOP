package series.series_5.exercices.exo_2;

public interface Aquatic {
    public abstract void swim();
}
