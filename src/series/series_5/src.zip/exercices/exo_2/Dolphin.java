package series.series_5.exercices.exo_2;

public class Dolphin extends Mammal implements Aquatic {
    public Dolphin (int age, int weight, String sex){
        super(age, weight, sex);
    }

    @Override
    public void nurse() {
        ;
    }

    @Override
    public void swim() {
        ;
    }

    @Override
    protected void doSound() {
        ;
    }

    @Override
    protected void est() {
        ;
    }
}
