package series.series_5.exercices.exo_2;

public interface Moultable {
    public abstract void moult();
}
