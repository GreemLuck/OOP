package series.series_5.exercices.exo_2;

public interface Lactating {
    abstract void nurse();
}
