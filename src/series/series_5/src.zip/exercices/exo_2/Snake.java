package series.series_5.exercices.exo_2;

public class Snake extends Oviparus implements Moultable{
    public Snake(int age, int weight, String sex){
        super(age, weight, sex);
    }

    @Override
    protected void doSound() {
        ;
    }

    @Override
    protected void est() {
        ;
    }

    @Override
    public void moult() {
        ;
    }

    @Override
    public void layingEggs() {
        ;
    }
}
