package project.Controller;

public interface Killable {
    void die();
}
