package project.Model;

import java.awt.*;

public abstract class Shot extends Sprite {
    public Shot(Image img, int x, int y){
        super(img,x,y);
    }
}
