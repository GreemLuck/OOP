package series.series_5.exercices.exo_3;

public class Character {
    final String bookTitle;
    final String name;
    final int age;

    public Character(String bookTitle, String name, int age) {
        this.bookTitle = bookTitle;
        this.name = name;
        this.age = age;
    }
}
