package core;

import javax.swing.*;

public class Main{

    public static void main(String[] args) {
        init();
    }

    private static void init() {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(content());
        frame.pack();
        frame.setVisible(true);
    }

    private static JPanel content() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Hello World ! This is my first Swing application");
        JButton button = new JButton("Exit");
        button.addActionListener(e -> System.exit(0));
        panel.add(label);
        panel.add(button);
        return panel;
    }
}
