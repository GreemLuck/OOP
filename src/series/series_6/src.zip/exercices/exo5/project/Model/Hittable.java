package project.Model;

public interface Hittable {
    void getShot();
    void die();
}
