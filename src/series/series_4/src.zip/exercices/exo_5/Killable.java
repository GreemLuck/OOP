package project;

public interface Killable {
    void die();
}
