package project;
import java.awt.*;

abstract class Shot extends Sprite {
    public Shot(Image img, int x, int y){
        super(img,x,y);
    }
}
