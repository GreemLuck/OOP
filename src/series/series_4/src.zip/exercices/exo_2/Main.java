package week_4.exercise.ex2;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Person> employees = new ArrayList<Person>();

        Manager jim = new Manager("Jim", 23, 34);
        employees.add(jim);

        Manager john = new Manager("John");
        john.setSalary(88);
        employees.add(john);

        Worker bill = new Worker("Bill");
        bill.setSalary(22);
        employees.add(bill);

        Worker bob = new Worker("Bob", 100);
        employees.add(bob);

        Manager jack = new Manager("Jack", 55);
        employees.add(jack);

        for (Person employee : employees) {
            employee.printSalary();
        }

    }
}
