package week_4.exercise.ex2;

public class Worker extends Person implements Employee{
    private int salary;

    public Worker(String name) {
        super(name);
    }

    public Worker(String name, int salary) {
        super(name);
        this.salary = salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void printSalary() {
        System.out.printf("%d%n", this.salary);
    }
}
