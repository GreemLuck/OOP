package week_4.exercise.ex2;

public abstract class Person {
    protected String name;

    public Person(String name) {
        this.name = name;
    }

    public void printName() {
        System.out.printf("%s%n", this.name);
    }

    public abstract void printSalary();
}
