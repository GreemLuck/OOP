package week_4.exercise.ex2;

public interface MotivatedEmployee extends Employee{

    public void printBonus() ;
}
