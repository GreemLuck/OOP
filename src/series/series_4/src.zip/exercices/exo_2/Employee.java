package week_4.exercise.ex2;

public interface Employee {

    public void printSalary() ;

}
