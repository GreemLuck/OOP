package week_4.exercise.ex2;

public class Manager extends Person implements MotivatedEmployee {
    private int bonus;
    private int salary;

    public Manager(String name, int salary, int bonus) {
        super(name);
        this.bonus = bonus;
        this.salary = salary;
    }

    public Manager(String name) {
        super(name);
    }

    public Manager(String name, int salary) {
        super(name);
        this.salary = salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void printSalary() {
        System.out.printf("%d%n", this.salary);
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

    public void printBonus() {
        System.out.printf("%d%n", this.bonus);
    }

}
