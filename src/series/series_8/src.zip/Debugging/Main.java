package week_8.Debugging;

import java.io.IOException ;

public class Main {
    public static void main ( String [] args ) throws IOException {
        foo ();
        bar ();
    }

    static private void foo () {
        throw new IllegalStateException ();
    }

    static private void bar () throws IOException {
        throw new IOException();
    }
}
