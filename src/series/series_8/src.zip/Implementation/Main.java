package week_8.Implementation;

public class Main {
    public static void main(String[] args) throws InsufficientFundsException {
        BankAccount account = new BankAccount(500);
        try{
            account.withdraw(600);
        }
        catch(InsufficientFundsException e){
            System.out.println(e);
        }

    }

}
