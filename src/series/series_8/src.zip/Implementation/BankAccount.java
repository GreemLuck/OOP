package week_8.Implementation;

public class BankAccount {
    private int funds;

    public BankAccount(int funds) {
        this.funds = funds;
    }

    public void withdraw(int money) throws InsufficientFundsException{
        if(this.funds < money){
            throw new InsufficientFundsException("Missing funds :" + (money-this.funds));
        }
        else {
            this.funds = this.funds - money;
        }
    }
}
