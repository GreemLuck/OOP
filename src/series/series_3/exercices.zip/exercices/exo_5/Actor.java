package project;

import java.awt.*;

public class Actor extends Sprite{

    public Actor(Image img, int x, int y) {
        super(img, x, y);
    }

    private void collision(){}

    private void move(){}
}
