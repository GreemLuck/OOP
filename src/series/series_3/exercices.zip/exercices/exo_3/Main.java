package series.series_3.exercices.exo_3;

public class Main {
    public static void main(String[] args) {
        Car car = new Car("MyCar");

        System.out.println(car);

        Car electricCar = new ElectricCar("MyElectricCar", 1000);

        System.out.println(electricCar);
    }
}
