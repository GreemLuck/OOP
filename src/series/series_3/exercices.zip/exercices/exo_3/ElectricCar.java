package series.series_3.exercices.exo_3;

public class ElectricCar extends Car {

    private int enginePower;

    public ElectricCar(final String model, final int enginePower){
        super(model);
        super.model = model;
        this.enginePower = enginePower;
    }

    @Override
    public String toString() {
        return "ElectricCar{" +
                "enginePower=" + enginePower +
                ", model='" + model + '\'' +
                '}';
    }
}
