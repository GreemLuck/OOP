package project.Model;

public enum Direction { UP, DOWN, RIGHT, LEFT }
