package project.Model;

public interface Movable {
    void move(Direction direction);
}
